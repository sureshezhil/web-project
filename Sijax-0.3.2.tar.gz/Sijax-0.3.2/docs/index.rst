.. Sijax documentation master file, created by
   sphinx-quickstart on Fri Mar  4 15:18:07 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Sijax's documentation!
=================================

:Author: Slavi Pantaleev<s.pantaleev_REMOVE@ME_gmail.com>
:Version: |release|
:Source: github.com_
:Bug tracker: `github.com/issues <https://github.com/spantaleev/sijax-python/issues>`_

Contents:

.. toctree::
   :maxdepth: 2

   intro
   how_to_setup
   usage
   comet
   upload
   api
   faq

.. _github.com: https://github.com/spantaleev/sijax-python

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

