# -*- coding: utf-8 -*-

from __future__ import (absolute_import, unicode_literals)

from . import plugin
from .core import Sijax

__title__ = 'sijax'
__version__ = '0.3.2'
__author__ = 'Slavi Pantaleev'
__license__ = 'BSD'
__copyright__ = 'Copyright 2011 Slavi Pantaleev'

