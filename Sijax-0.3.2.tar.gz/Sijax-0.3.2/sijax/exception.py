# -*- coding: utf-8 -*-

from __future__ import (absolute_import, unicode_literals)

class SijaxError(Exception):
    """Exception class for Sijax errors."""

